بسته‌ی کوچک ALOOKHOR (برای استفاده با نصب خودکار وردپرس / Softaculous)
=====================================================================

مراحل:
1) در cPanel گزینه‌ی «Softaculous Apps Installer» (یا «نصب خودکار وردپرس»)
   را باز کن و WordPress را داخل public_html نصب کن (پوشه باید خالی باشد).
   - در مرحله‌ی دیتابیس: اگر دیتابیس قدیمی هنوز موجود است، گزینه‌ی
     «Use Existing Database» را انتخاب و دیتابیس قدیمی را انتخاب کن
     (پیش‌فيل wp_ را هم چک کن). اگر پاک شده، دیتابیس جدید بساز.
   - در انتهای نصب روی «Permalink Structure» ساختار
     /%postname%/ را انتخاب کن.
2) حالا دو فایل این بسته را در public_html آپلود و Extract کن:
   - hello-elementor.zip  -> باید در public_html/wp-content/themes/hello-elementor باشد
     (اگر Extract مستقیم داخل themes/ انجام شود عالی است؛ در غیر این صورت
     پوشه‌ی hello-elementor را دستی داخل wp-content/themes جابه‌جا کن)
   - alookhor-control-center-3.10.19.zip -> در public_html/wp-content/plugins/
     Extract شود تا پوشه‌ی alookhor-control-center ساخته شود
3) از wp-admin:
   - Appearance > Themes: تم Hello Elementor را فعال کن
   - Plugins: alookhor-control-center را فعال کن
   - Plugins > Add New: افزونه‌ی WooCommerce را نصب و فعال کن
4) Settings > General: آدرس سایت https://alookhor.ir باشد
   Settings > Permalinks: /%postname%/ و Save
5) https://alookhor.ir را باز کن و سربرگ را چک کن؛ تنظیمات سربرگ از
   Control Center > Settings است.

نکته: فایل .htaccess داخل این بسته جایگزین .htaccess موجود شود
(محتوای استاندارد وردپرس است).
